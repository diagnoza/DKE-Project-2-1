package gui;

public class Triangle {
    public int[] x;
    public int[] y;

    public Triangle(int[] x, int[] y) {
        this.x = x;
        this.y = y;
    }

}