package gui;

// just for debugging. Will probably not serve a big purpose in the long run
class IllegalColourException extends Exception {
    IllegalColourException(String message) {
        super(message);
    }
}